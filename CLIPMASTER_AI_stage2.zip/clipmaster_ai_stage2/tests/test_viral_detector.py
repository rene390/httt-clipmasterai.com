import unittest
from types import SimpleNamespace
from app.viral_detector import detect_viral_moments, score_window

def make_segments(text, start=0, duration=50):
    words = text.split()
    # Build simple timed transcript segments for deterministic unit tests.
    return [
        SimpleNamespace(
            start=start + i * duration / len(words),
            end=start + (i + 1) * duration / len(words),
            text=word,
            words=None,
            avg_logprob=-0.2
        )
        for i, word in enumerate(words)
    ]

class ViralDetectorTests(unittest.TestCase):
    def test_detects_conflict_hook_window(self):
        text = (
            "No vas a creer la verdad. Me mentiste y nunca pensé que harías "
            "esto. Estoy muy triste por esta traición. ¿Por qué me engañaste? "
            "Esto es increíble y nadie esperaba esta sorpresa."
        )
        segments = make_segments(text)
        result = detect_viral_moments(
            segments, min_duration=30, max_duration=60,
            step=5, max_clips=3, min_score=-100
        )
        self.assertTrue(result)
        self.assertTrue(all(c.end > c.start for c in result))

    def test_empty_transcript_returns_empty(self):
        self.assertEqual(detect_viral_moments([]), [])

    def test_invalid_duration_raises(self):
        with self.assertRaises(ValueError):
            detect_viral_moments([], min_duration=60, max_duration=30)

if __name__ == "__main__":
    unittest.main()
