"""
Heuristic viral-moment detector.

This is a transparent baseline, not a trained emotion classifier.
It scores sliding transcript windows using:
- hook / surprise / conflict / humor / emotion phrase signals
- punctuation and question/exclamation signals
- speech density
- transcript confidence when available

A future LLM or audio emotion model can replace/enrich score_window().
"""
from dataclasses import dataclass, asdict
from typing import Iterable, Optional
import re

HOOK_TERMS = {
    "increíble", "increiblemente", "nadie", "nunca", "jamás",
    "secreto", "verdad", "mentira", "escucha", "mira", "atención",
    "no puedo creer", "no vas a creer", "lo que pasó"
}
SURPRISE_TERMS = {
    "sorpresa", "de repente", "resulta que", "al final", "inesperado",
    "no me lo esperaba", "qué pasó", "que paso", "increíble", "wow"
}
CONFLICT_TERMS = {
    "mentiroso", "mentirosa", "traición", "traicion", "engañó",
    "engano", "culpa", "pelea", "discutir", "problema", "odio",
    "estás equivocado", "estas equivocado", "no es verdad", "te dije"
}
HUMOR_TERMS = {
    "jajaja", "jeje", "ja ja", "chiste", "gracioso", "ridículo",
    "ridicula", "qué risa", "que risa", "broma", "payaso"
}
EMOTION_TERMS = {
    "te amo", "te quiero", "lloré", "llore", "lágrimas", "lagrimas",
    "triste", "feliz", "miedo", "vergüenza", "perdón", "perdon",
    "gracias", "familia", "corazón", "corazon"
}

@dataclass
class ClipCandidate:
    start: float
    end: float
    score: float
    reasons: list[str]
    text: str

    def to_dict(self):
        return asdict(self)


def _norm(text: str) -> str:
    return re.sub(r"\s+", " ", (text or "").lower()).strip()


def _count_hits(text: str, terms: set[str]) -> int:
    return sum(text.count(term) for term in terms if term in text)


def score_window(segments: list, start: float, end: float) -> ClipCandidate:
    chosen = [
        s for s in segments
        if float(getattr(s, "start", 0)) < end
        and float(getattr(s, "end", 0)) > start
    ]
    text = " ".join(getattr(s, "text", "") for s in chosen).strip()
    normalized = _norm(text)
    words = re.findall(r"\b[\wáéíóúüñ]+\b", normalized, flags=re.UNICODE)
    word_count = len(words)
    duration = max(1.0, end - start)
    words_per_minute = word_count / duration * 60

    reasons = []
    score = 0.0

    hook_hits = _count_hits(normalized, HOOK_TERMS)
    surprise_hits = _count_hits(normalized, SURPRISE_TERMS)
    conflict_hits = _count_hits(normalized, CONFLICT_TERMS)
    humor_hits = _count_hits(normalized, HUMOR_TERMS)
    emotion_hits = _count_hits(normalized, EMOTION_TERMS)

    if hook_hits:
        score += min(18, hook_hits * 6)
        reasons.append("frase gancho")
    if surprise_hits:
        score += min(18, surprise_hits * 7)
        reasons.append("sorpresa o revelación")
    if conflict_hits:
        score += min(20, conflict_hits * 7)
        reasons.append("conflicto o discusión")
    if humor_hits:
        score += min(16, humor_hits * 8)
        reasons.append("humor")
    if emotion_hits:
        score += min(16, emotion_hits * 5)
        reasons.append("emoción")

    exclamations = text.count("!") + text.count("¡")
    questions = text.count("?") + text.count("¿")
    score += min(8, exclamations * 2 + questions * 1.5)
    if exclamations or questions:
        reasons.append("entonación expresiva en el texto")

    # Penalize nearly empty windows; reward moderate conversational density.
    if 75 <= words_per_minute <= 190:
        score += 12
        reasons.append("ritmo de conversación")
    elif words_per_minute < 35:
        score -= 12
        reasons.append("poca voz detectada")
    elif words_per_minute > 250:
        score += 3

    # Whisper average_logprob is optional and may be absent.
    confidences = [
        getattr(s, "avg_logprob", None)
        for s in chosen
        if getattr(s, "avg_logprob", None) is not None
    ]
    if confidences:
        avg_conf = sum(confidences) / len(confidences)
        score += max(-5, min(5, (avg_conf + 1.0) * 8))

    if word_count < 12:
        score -= 20
        reasons.append("muy poco contenido hablado")

    return ClipCandidate(
        start=max(0.0, start),
        end=end,
        score=round(score, 2),
        reasons=reasons or ["contenido hablado"],
        text=text
    )


def detect_viral_moments(
    segments: list,
    min_duration: int = 30,
    max_duration: int = 60,
    step: int = 10,
    max_clips: int = 10,
    min_score: float = 8.0,
) -> list[ClipCandidate]:
    if min_duration < 1 or max_duration < min_duration:
        raise ValueError("Duraciones inválidas")

    if not segments:
        return []

    total_end = max(float(getattr(s, "end", 0)) for s in segments)
    if total_end < min_duration:
        return []

    candidates = []
    # Prefer 45s windows, but also test shorter/longer permitted windows.
    durations = sorted(set([min_duration, (min_duration + max_duration) // 2, max_duration]))

    for duration in durations:
        last_start = max(0.0, total_end - duration)
        starts = []
        t = 0.0
        while t <= last_start:
            starts.append(t)
            t += max(1, step)
        if not starts or (last_start - starts[-1]) > 1:
            starts.append(last_start)

        for start in starts:
            end = min(total_end, start + duration)
            if end - start < min_duration:
                continue
            candidate = score_window(segments, start, end)
            if candidate.score >= min_score:
                candidates.append(candidate)

    # Highest scores first, suppress highly overlapping duplicates.
    candidates.sort(key=lambda c: c.score, reverse=True)
    selected = []
    for candidate in candidates:
        overlaps = False
        for existing in selected:
            intersection = max(
                0.0,
                min(candidate.end, existing.end) - max(candidate.start, existing.start)
            )
            shorter = min(
                candidate.end - candidate.start,
                existing.end - existing.start
            )
            if shorter > 0 and intersection / shorter > 0.55:
                overlaps = True
                break
        if not overlaps:
            selected.append(candidate)
        if len(selected) >= max_clips:
            break

    return sorted(selected, key=lambda c: c.start)
