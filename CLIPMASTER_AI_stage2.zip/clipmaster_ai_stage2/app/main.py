from fastapi import FastAPI, UploadFile, File, BackgroundTasks, HTTPException
from fastapi.responses import FileResponse
from pathlib import Path
from uuid import uuid4
import shutil
import threading

from .config import UPLOAD_DIR, OUTPUT_DIR, ALLOWED_EXTENSIONS, MAX_UPLOAD_MB
from .processor import process_video

app = FastAPI(title="CLIPMASTER AI", version="0.2.0")
jobs = {}
jobs_lock = threading.Lock()


def _run_job(job_id: str, video_path: str):
    try:
        with jobs_lock:
            jobs[job_id]["status"] = "processing"
        result = process_video(video_path, job_id)
        with jobs_lock:
            jobs[job_id].update(result)
            jobs[job_id]["status"] = "completed"
    except Exception as exc:
        with jobs_lock:
            jobs[job_id]["status"] = "failed"
            jobs[job_id]["error"] = str(exc)


@app.get("/health")
def health():
    return {"ok": True, "service": "CLIPMASTER AI"}


@app.post("/jobs/upload")
async def upload_video(background_tasks: BackgroundTasks, file: UploadFile = File(...)):
    suffix = Path(file.filename or "").suffix.lower()
    if suffix not in ALLOWED_EXTENSIONS:
        raise HTTPException(400, "Formato no compatible.")

    job_id = str(uuid4())
    target = UPLOAD_DIR / f"{job_id}{suffix}"
    size = 0

    try:
        with target.open("wb") as out:
            while chunk := await file.read(1024 * 1024):
                size += len(chunk)
                if size > MAX_UPLOAD_MB * 1024 * 1024:
                    target.unlink(missing_ok=True)
                    raise HTTPException(413, "El video supera el límite permitido.")
                out.write(chunk)
    finally:
        await file.close()

    with jobs_lock:
        jobs[job_id] = {
            "job_id": job_id,
            "status": "queued",
            "clips": [],
            "source_file": target.name
        }

    background_tasks.add_task(_run_job, job_id, str(target))
    return {"job_id": job_id, "status": "queued"}


@app.get("/jobs/{job_id}")
def get_job(job_id: str):
    with jobs_lock:
        job = jobs.get(job_id)
        if not job:
            raise HTTPException(404, "Trabajo no encontrado.")
        return job


@app.get("/clips/{filename}")
def download_clip(filename: str):
    # Restrict download to generated MP4/SRT files inside OUTPUT_DIR.
    if Path(filename).name != filename or not filename.endswith((".mp4", ".srt")):
        raise HTTPException(400, "Nombre de archivo no válido.")
    path = OUTPUT_DIR / filename
    if not path.is_file():
        raise HTTPException(404, "Archivo no encontrado.")
    return FileResponse(path, filename=filename)
