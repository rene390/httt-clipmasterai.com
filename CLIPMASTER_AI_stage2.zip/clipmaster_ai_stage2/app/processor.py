"""End-to-end video processing."""
from pathlib import Path
from faster_whisper import WhisperModel

from .config import WHISPER_MODEL, WHISPER_DEVICE, WHISPER_COMPUTE_TYPE
from .viral_detector import detect_viral_moments
from .renderer import render_vertical_clip

_model = None

def get_model():
    global _model
    if _model is None:
        _model = WhisperModel(
            WHISPER_MODEL,
            device=WHISPER_DEVICE,
            compute_type=WHISPER_COMPUTE_TYPE
        )
    return _model


def process_video(
    video_path: str,
    job_id: str,
    min_duration: int = 30,
    max_duration: int = 60,
    max_clips: int = 10,
    quality: str = "4K",
):
    model = get_model()
    segments_iter, info = model.transcribe(
        video_path,
        language="es",
        word_timestamps=True,
        vad_filter=True,
        beam_size=5
    )
    segments = list(segments_iter)

    candidates = detect_viral_moments(
        segments,
        min_duration=min_duration,
        max_duration=max_duration,
        max_clips=max_clips
    )

    rendered = []
    for index, candidate in enumerate(candidates, start=1):
        rendered.append(
            render_vertical_clip(
                video_path, segments, candidate, index, quality
            )
        )

    return {
        "job_id": job_id,
        "language": getattr(info, "language", "es"),
        "duration": getattr(info, "duration", None),
        "clips": rendered,
        "message": "No se encontraron ventanas con puntuación suficiente."
                   if not rendered else "Procesamiento terminado."
    }
