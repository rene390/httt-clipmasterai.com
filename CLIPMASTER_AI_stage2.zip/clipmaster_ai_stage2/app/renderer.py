"""FFmpeg vertical rendering and burned-in subtitles."""
from pathlib import Path
import subprocess
import json
import shutil

from .config import OUTPUT_WIDTH, OUTPUT_HEIGHT, OUTPUT_DIR
from .subtitles import write_srt


def require_ffmpeg():
    if not shutil.which("ffmpeg"):
        raise RuntimeError("FFmpeg no está instalado o no está en PATH")


def _ffmpeg_filter_path(path: str) -> str:
    # FFmpeg filter syntax needs escaping for drive colon, quotes and backslashes.
    value = str(Path(path).resolve()).replace("\\", "/")
    value = value.replace(":", r"\:")
    value = value.replace("'", r"\'")
    return value


def render_vertical_clip(
    source_video: str,
    segments: list,
    candidate,
    clip_number: int,
    quality: str = "4K",
) -> dict:
    require_ffmpeg()

    width, height = OUTPUT_WIDTH, OUTPUT_HEIGHT
    if quality.upper() == "1080P":
        width, height = 1080, 1920
    elif quality.upper() != "4K":
        raise ValueError("Calidad admitida: 1080p o 4K")

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    stem = f"clip_{clip_number:02d}"
    srt_path = OUTPUT_DIR / f"{stem}.srt"
    output_path = OUTPUT_DIR / f"{stem}.mp4"

    write_srt(segments, candidate.start, candidate.end, str(srt_path))

    subtitle_filter = _ffmpeg_filter_path(str(srt_path))
    # Center crop. Smart face tracking is a later upgrade; this does not
    # automatically follow a speaker's face.
    vf = (
        f"scale={width}:{height}:force_original_aspect_ratio=increase,"
        f"crop={width}:{height},setsar=1,"
        f"subtitles='{subtitle_filter}':"
        "force_style='FontName=Arial,FontSize=22,"
        "Bold=1,Outline=3,Shadow=1,Alignment=2,"
        "MarginV=150,PrimaryColour=&H00FFFFFF&,"
        "OutlineColour=&H00000000&'"
    )

    cmd = [
        "ffmpeg", "-y",
        "-ss", f"{candidate.start:.3f}",
        "-i", str(source_video),
        "-t", f"{candidate.end - candidate.start:.3f}",
        "-vf", vf,
        "-c:v", "libx264",
        "-preset", "medium",
        "-crf", "18",
        "-pix_fmt", "yuv420p",
        "-c:a", "aac",
        "-b:a", "192k",
        "-movflags", "+faststart",
        str(output_path)
    ]
    subprocess.run(cmd, check=True, capture_output=True, text=True)

    return {
        "video": str(output_path),
        "subtitles": str(srt_path),
        "width": width,
        "height": height,
        "duration": round(candidate.end - candidate.start, 2),
        "score": candidate.score,
        "reasons": candidate.reasons,
        "transcript_excerpt": candidate.text[:500],
    }
