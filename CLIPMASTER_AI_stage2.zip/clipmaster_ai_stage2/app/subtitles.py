"""Create readable Spanish SRT subtitles from Faster-Whisper word timestamps."""
from pathlib import Path
import re


def _srt_time(seconds: float) -> str:
    ms = max(0, round(seconds * 1000))
    hours, ms = divmod(ms, 3_600_000)
    minutes, ms = divmod(ms, 60_000)
    secs, ms = divmod(ms, 1000)
    return f"{hours:02}:{minutes:02}:{secs:02},{ms:03}"


def _clean_word(word: str) -> str:
    return re.sub(r"\s+", " ", (word or "").strip())


def words_to_cues(
    segments: list,
    clip_start: float,
    clip_end: float,
    max_words: int = 7,
    max_chars: int = 38,
) -> list[tuple[float, float, str]]:
    """
    Returns cue tuples (relative_start, relative_end, text).
    Uses word timestamps when available. Falls back to segment timestamps.
    """
    tokens = []

    for seg in segments:
        seg_start = float(getattr(seg, "start", 0))
        seg_end = float(getattr(seg, "end", 0))
        if seg_end <= clip_start or seg_start >= clip_end:
            continue

        words = getattr(seg, "words", None) or []
        if words:
            for w in words:
                ws = getattr(w, "start", None)
                we = getattr(w, "end", None)
                wt = _clean_word(getattr(w, "word", ""))
                if ws is None or we is None or not wt:
                    continue
                if we <= clip_start or ws >= clip_end:
                    continue
                tokens.append((
                    max(0.0, float(ws) - clip_start),
                    min(clip_end - clip_start, float(we) - clip_start),
                    wt
                ))
        else:
            # Segment-level fallback: distribute approximate word timings.
            raw_words = (getattr(seg, "text", "") or "").split()
            if not raw_words:
                continue
            left = max(seg_start, clip_start)
            right = min(seg_end, clip_end)
            span = max(0.1, right - left)
            step = span / len(raw_words)
            for i, word in enumerate(raw_words):
                tokens.append((
                    left - clip_start + i * step,
                    min(right - clip_start, left - clip_start + (i + 1) * step),
                    _clean_word(word)
                ))

    tokens.sort(key=lambda x: x[0])

    cues = []
    current = []
    cue_start = None
    cue_end = None
    current_chars = 0

    for start, end, word in tokens:
        extra = len(word) + (1 if current else 0)
        if current and (
            len(current) >= max_words or current_chars + extra > max_chars
        ):
            cues.append((cue_start, max(cue_start + 0.15, cue_end), " ".join(current)))
            current, cue_start, cue_end, current_chars = [], None, None, 0

        if cue_start is None:
            cue_start = start
        current.append(word)
        cue_end = max(end, start + 0.12)
        current_chars += len(word) + (1 if len(current) > 1 else 0)

    if current:
        cues.append((cue_start, max(cue_start + 0.15, cue_end), " ".join(current)))

    # Ensure strictly positive durations and monotonic cue starts.
    fixed = []
    previous_end = 0.0
    for start, end, text in cues:
        start = max(previous_end, start)
        end = max(start + 0.15, end)
        fixed.append((start, end, text))
        previous_end = start
    return fixed


def write_srt(segments: list, clip_start: float, clip_end: float, output_path: str) -> str:
    cues = words_to_cues(segments, clip_start, clip_end)
    lines = []
    for i, (start, end, text) in enumerate(cues, 1):
        lines.extend([
            str(i),
            f"{_srt_time(start)} --> {_srt_time(end)}",
            text,
            ""
        ])
    Path(output_path).write_text("\n".join(lines), encoding="utf-8")
    return output_path
