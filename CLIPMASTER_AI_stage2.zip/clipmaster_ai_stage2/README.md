# CLIPMASTER AI — Stage 2

Motor inicial para:
- transcribir español con Faster-Whisper;
- puntuar ventanas de 30–60 segundos para encontrar momentos candidatos;
- evitar clips demasiado repetidos;
- crear subtítulos SRT a partir de marcas de tiempo de palabras;
- renderizar MP4 vertical 9:16 con subtítulos quemados;
- exportar a 1080p o 4K (2160x3840).

## Requisitos

- Python 3.10+
- FFmpeg instalado y disponible en PATH
- Recomendado: GPU NVIDIA para transcripción y renderizado más rápidos
- Espacio de almacenamiento suficiente

## Instalación

```bash
python -m venv .venv
# Windows:
.venv\\Scripts\\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
```

Instala FFmpeg desde https://ffmpeg.org/download.html y verifica:

```bash
ffmpeg -version
```

## Ejecutar API

Desde la carpeta del proyecto:

```bash
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

Documentación interactiva:
http://localhost:8000/docs

## Subir un archivo de video autorizado

```bash
curl -X POST "http://localhost:8000/jobs/upload" \
  -F "file=@mi_video.mp4"
```

La respuesta contiene `job_id`. Consulta el estado:

```bash
curl "http://localhost:8000/jobs/EL_JOB_ID"
```

Los MP4 terminados se guardan en `clips/` y se pueden descargar mediante:

```text
http://localhost:8000/clips/clip_01.mp4
```

## Pruebas unitarias

```bash
python -m unittest discover -s tests -v
```

Las pruebas cubren la lógica básica del detector. No ejecutan Whisper ni FFmpeg y no equivalen a una prueba de procesamiento audiovisual real.

## Configuración opcional

Variables de entorno:
- `WHISPER_MODEL`: tiny, base, small, medium, large-v3 (por defecto small)
- `WHISPER_DEVICE`: cpu o cuda
- `WHISPER_COMPUTE_TYPE`: int8, float16, etc.
- `MAX_UPLOAD_MB`: límite de subida (por defecto 2048)

## Limitaciones importantes

1. El detector actual es heurístico. Usa vocabulario, puntuación y densidad de palabras; no comprende el contexto completo ni mide emociones reales.
2. El encuadre 9:16 es un recorte centrado. Aún no sigue automáticamente rostros o al hablante.
3. La salida 4K escala el video a 2160x3840; no crea detalle real si la fuente es de menor resolución.
4. Los subtítulos usan marcas de tiempo de Whisper. La segmentación se agrupa en bloques cortos y puede necesitar ajustes visuales.
5. Este servidor acepta archivos subidos. No descarga videos de YouTube. Para ello se necesita una fuente autorizada o el archivo original con derechos/permisos.
6. Para producción: añadir autenticación, límites por usuario, almacenamiento de objetos, cola Redis/Celery, cancelación de trabajos, limpieza de temporales y aislamiento de procesos FFmpeg.
7. El estado de trabajos se guarda en memoria y se pierde al reiniciar el servidor. Este ejemplo es una base funcional, no un despliegue de producción.
